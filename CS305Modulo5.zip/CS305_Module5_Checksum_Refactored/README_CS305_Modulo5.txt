CS-305ES - Módulo 5: Verificación de suma de comprobación

1. Abra el proyecto en Eclipse como proyecto Maven existente.
2. Abra:
   src/main/java/com/snhu/sslserver/ServerApplication.java
3. Cambie:
   TU NOMBRE Y APELLIDO
   por su nombre y apellido reales.
4. Ejecute ServerApplication como Spring Boot App.
5. Abra en el navegador:
   https://localhost:8443/hash
6. Acepte la advertencia del certificado local si Eclipse/Spring la presenta.
7. La página debe mostrar:
   - data: su nombre y apellido
   - algorithm: SHA-256
   - checksum: el valor hexadecimal de 64 caracteres

Nota: El proyecto base ya incluye la configuración HTTPS y el archivo keystore.
