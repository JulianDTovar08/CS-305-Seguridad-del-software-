package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {

    @RequestMapping("/hash")
    public String myHash() {
        // Reemplace este texto con su nombre y apellido.
        String data = "TU NOMBRE Y APELLIDO";
        String algorithm = "SHA-256";

        try {
            // Crea e inicializa el objeto MessageDigest con SHA-256.
            MessageDigest md = MessageDigest.getInstance(algorithm);

            // Genera el valor hash a partir de la cadena de datos.
            byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));

            // Convierte el valor hash de bytes a hexadecimal.
            String checksum = bytesToHex(hash);

            return "<p>data: " + data
                    + "</p><p>algorithm: " + algorithm
                    + "</p><p>checksum: " + checksum + "</p>";

        } catch (NoSuchAlgorithmException e) {
            return "<p>Error: el algoritmo " + algorithm
                    + " no está disponible.</p>";
        }
    }

    // Convierte cada byte del hash a su representación hexadecimal.
    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();

        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);

            if (hex.length() == 1) {
                hexString.append('0');
            }

            hexString.append(hex);
        }

        return hexString.toString();
    }
}
